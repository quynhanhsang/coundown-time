        /*
     * +Coutdownt v1.0.0
     *
     * Copyright 2013, Sangtran | Email:sangtrank64@gmail.com
     * Dual licensed under the MIT and GPL licenses:
     */
    (function($){
        $.fn.plugindownCount = function(options){
            var index = this;
            if(index.length === 0 ){
                return false;
            }
            var setting = {
                date: null,
                offset: null,
                init:function(){
                    if(!setting.date){
                        $.error('Date is not defined.');
                    }
                    if(!Date.parse(setting.date)){
                        $.error('Incorrect date format');
                    }
                    setting.indexHtml();
                    setInterval(setting.countDown, 1000);
                },
                indexHtml(){
                    html = '<div class="curren-dateime">';
                    html += '<div class="curren-dateime-days"><span class="days"></span><p class="days_ref"></p></div>';
                    html += '<div class="curren-dateime-hours"><span class="hours"></span>  <p class="hours_ref"></p></div>';
                    html += '<div class="curren-dateime-minutes"><span class="minutes"></span><p class="minutes_ref"></p></div>';
                    html += '<div class="curren-dateime-seconds"><span class="seconds last"></span><p class="secons_ref"></p></div>';
                    html += '</div>';
                    index.append(html);
                },
                /*--------------------------
            
                    get date
            
                ----------------------------*/
                currentDate:function(){
                    ////get dat client 
                    var date  = new Date;

                    //get date time utc
                    var utc  = date.getTime() + (date.getTimezoneOffset() * 60000);

                    var new_date = new Date(utc + (3600000*setting.offset));
                    return new_date;
                },
                 /*--------------------------
            
                    get countdown
            
                ----------------------------*/
                countDown(){
                    var _date = new Date(setting.date);
                    currendate =  setting.currentDate();
                    
                    var tatal_day  = _date - currendate;
                    if(tatal_day < 0) {
                        clearInterval(interval);
                        return;
                    }

                    var secon = 1000,
                        minute = secon * 60,
                        hour = minute * 60,
                        day = hour * 24;

                    //// calculate date
                    var days  =  Math.floor(tatal_day / day);
                    var hours =  Math.floor((tatal_day % day ) / hour);
                    var minutes =  Math.floor((tatal_day % hour ) / minute);
                    var secons =  Math.floor((tatal_day % minute ) / secon);

                    /// fix time -> number
                    days = (String(days.length) >= 2 ? days : '0' +days);
                    hours = (String(hours.length) >= 2 ? hours : '0' +hours);
                    minutes = (String(minutes.length) >= 2 ? minutes : '0' +minutes);
                    secons = (String(secons.length) >= 2 ? secons : '0' + secons);


                    var ref_days = (days === 1) ? 'day' : 'days',
                    ref_hours = (hours === 1) ? 'hour' : 'hours',
                    ref_minutes = (minutes === 1) ? 'minute' : 'minutes',
                    ref_secons = (secons === 1) ? 'second' : 'seconds';

                    ////set to dom
                    
                    index.find('.days').text(days);
                    index.find('.hours').text(hours);
                    index.find('.minutes').text(minutes);
                    index.find('.seconds').text(secons);

                    index.find('.days_ref').text(ref_days);
                    index.find('.hours_ref').text(ref_hours);
                    index.find('.minutes_ref').text(ref_minutes);
                    index.find('.secons_ref').text(ref_secons);
                }
            };

            $.extend(setting, options);
            setting.init();
        }

    })(jQuery);

